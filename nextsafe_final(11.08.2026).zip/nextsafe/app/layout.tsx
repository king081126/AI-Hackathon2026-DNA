import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NextSafe — Your next safe step",
  description: "Clear digital safety guidance for people and small businesses. An independent DNA × Since AI prototype.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
