# Project instructions

Keep the consumer interface and app advice English-only. The offline benchmark adapter may retain other required languages. Use one policy engine; regenerate browser files with `node cli/build-browser.mjs` and verify English parity after changes.

Read README.md and CODEX_TASK.md. Preserve the original challenge-kit evaluator, schemas and data. Never use case IDs, scenario-family labels, simulation facts, reference answers or ground-truth fields during inference. Dev evaluation is for development, not independent validation. Do not claim hidden-test accuracy without organizer labels.

Mask optional context before reasoning and require actual consent before using it. Never fake live scans, links, account access, approvals or handoffs. Do not store API keys in the browser or source repository. Use only synthetic inputs for the demo.

Before delivery run engine tests, TypeScript checks, a production build, the supplied submission validator and relevant development evaluation. Manually review safety-sensitive advice and report verification limits honestly. Do not modify the evaluator to inflate results.
