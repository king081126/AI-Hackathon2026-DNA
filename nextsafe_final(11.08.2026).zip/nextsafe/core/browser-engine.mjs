import { PROCEDURES, STEPS, QUESTIONS, textAt } from './knowledge.en.mjs';

export const VERSION = '0.1.0';
const KEYS = ['case_id','journey','audience','locale','language','persona','entry_point','user_identified','opening_message','signals','signal_availability','consent'];
export const visibleInput = c => Object.fromEntries(KEYS.filter(k => k in c).map(k => [k, structuredClone(c[k])]));
const get = (o,p) => p.split('.').reduce((v,k) => v?.[k],o);
const put = (o,p,v) => { if(p.split('.').some(k=>['__proto__','constructor','prototype'].includes(k)))return; const ks=p.split('.'); let cur=o; for(const k of ks.slice(0,-1))cur=cur[k]??={}; cur[ks.at(-1)]=v; };
const match = (s,r) => r.test(String(s??'').toLowerCase());
export function answerPolarity(s) {
 const t=String(s??'').toLowerCase();
 if(match(t,/i (haven't|have not|didn't|did not|don't|do not)|\bno[,.! ]|^no$|not (yet|entered|shared|paid)|nobody|didn.t order|neither|en (ole|syött|anta|luke|kirjaut|tilan|avann|maks|teh|asent)|ei (ole|tilan)|kukaan ei|emme|en,|^en$|inte|^nej|haven.t checked/))return false;
 if(match(t,/i.m not sure|i don.t (know|remember)|en tiedä|en muista|osaa sanoa|vet inte|not sure/))return null;
 if(match(t,/yes|yeah|i (typed|entered|gave|read|paid|logged|ordered|did|installed|approved|transferred|opened)|already paid|^i did|myself|on holiday|i.m (logging|signing)|joo|kyllä|syötin|kirjoitin|annoin|luin|maksoin|kirjauduin|tilasin|itse|asensin|sallin|painoin|lomalla|\bja\b|skrev|betalade|läste|beställde|själv|i did/))return true;
 return null;
}

// Mask optional personal context BEFORE policy selection; pre-grants are retained.
export function authorizedInput(input,granted=[]) {
 const c=visibleInput(input); c.signals??={}; c.consent??={requires_consent:[],pre_granted:[]};
 const allowed=new Set([...(c.consent.pre_granted??[]),...granted]);
 for(const p of c.consent.requires_consent??[])if(!allowed.has(p))put(c.signals,p,'available_with_consent');
 return c;
}

function policeCallProcedure(description, context, facts) {
 const transferRequested = match(context, /safe account|secure account|turvatili|säkert konto|transfer.{0,35}(money|funds|savings)|send.{0,25}money|pay.{0,25}(fine|fee)|(?:asked|told|demanded)[^.!?]{0,40}\bpay\b|siirtämään.{0,25}(raha|säästö)|överför.{0,25}pengar/);
 const codeRequested = match(context, /(?:verification|confirmation|payment|banking|security|one.time) code|\b(?:otp|pin)\b|tunnusluku|vahvistuskoodi|bekräftelsekod/);
 const detailsRequested = match(context, /bank(?:ing)? (?:details|credentials|login)|card (?:details|number)|identity document|passport|pankkitunn|pankkitieto|korttitieto|henkilöllisyystodistus|bankuppgifter|kortuppgifter|identitetshandling/);
 // Use the user's account of completed actions, not what the caller requested.
 const transferred = match(description, /\bi (?:already |may have )?(?:sent|transferred|moved|wired|paid) (?:them |him |her )?(?:some|money|funds|the money|the fine|the fee|[€£$]|\d)|\bsiirsin (?:jo|raha|\d)|jag (?:redan )?(?:överförde|betalade)/);
 const observedPayment = match(description, /\bi (?:see|saw|noticed|found) (?:an |a )?unauthori[sz]ed (?:bank )?(?:transfer|payment|transaction)/);
 const disclosed = match(description, /\bi (?:already |may have )?(?:shared|gave|sent|read|entered|showed|disclosed)\b(?!\s+(?:no|nothing)\b)[^.!?]{0,45}(?:bank(?:ing)? (?:details|credentials|login)|card (?:details|number)|identity document|passport|(?:verification|confirmation|payment|banking|security|one.time) code|\b(?:otp|pin)\b)|\b(?:annoin|kerroin|syötin|näytin)\b[^.!?]{0,30}(?:pankkitunn|korttitieto|tunnuslu|henkilöllisyystodistus)|jag (?:gav|delade|visade)\b[^.!?]{0,30}(?:bankuppgifter|kortuppgifter|bekräftelsekod|identitetshandling)/);
 const noTransfer = match(description, /\bi (?:didn.t|did not|haven.t|have not|never) (?:send|transfer|move|wire|pay)|\ben (?:siirtänyt|maksanut|lähettänyt)|jag (?:överförde|betalade|skickade) inte/);
 const noDisclosure = match(description, /\bi (?:didn.t|did not|haven.t|have not|never) (?:share|give|read|provide|disclose|show|enter)|\ben (?:antanut|kertonut|syöttänyt|näyttänyt)|jag (?:gav|delade|visade) inte/);
 const topics = [];
 if (transferRequested && !noTransfer) topics.push('payment_status');
 if (!noDisclosure && codeRequested) topics.push('code_shared');
 if (!noDisclosure && detailsRequested) topics.push('credentials_entered');
 const replies = topics.map(topic => {
  const reply = facts[topic];
  return match(reply, /not sure|don.t know|do not know|can.t tell|cannot tell|en tiedä|vet inte/) ? null : answerPolarity(reply);
 });

 if (transferred || observedPayment || disclosed || replies.includes(true)) {
  return {id:'bank', topic:null, extra:['report_police','hang_up_dont_call_back'], target:'human_advisor'};
 }

 const topic = topics.find(topic => facts[topic] === undefined) ?? null;
 const extra = replies.includes(null) ? ['police_bank_if_exposed'] : [];
 return {id:'police_check', topic, extra, target:undefined};
}

export function selectProcedure(c,facts={}) {
 const op=String(c.opening_message??'').toLowerCase();
 const artifact=c.signals?.artifact; const body=String(facts.message_content??artifact?.body??'').toLowerCase(); const all=op+' '+body;
 const isCall=c.journey==='suspicious_call'||artifact?.type==='call'||match(all,/\(call\)|\(puhelu\)|\(samtal\)/);
 const policeCall = (isCall || match(op, /called|phone call|video call|soitti|ringde/)) && match(all, /\bpolice\b|\blaw enforcement\b|poliisi|poliisiksi|\bpolisen\b|polisofficer/);
 const business=c.audience==='small_business'||c.journey==='smb_incident';
 const pol=t=>answerPolarity(facts[t]);
 let id='uncertain',topic=null,needs=[],extra=[],target=undefined,cite=null,conditional=false,risk=null;
 const choose=(p,t=null)=>{id=p;topic=t;};
 // Safety, privacy and money loss take priority over low-quality reputation signals.
 if(match(op,/who owns|find out who|publish.{0,20}name|identify.{0,20}scammer|trace.{0,20}(person|number)|kuka omistaa|omistaa numeron|julkaista|etsi.{0,30}(osoite|huijari)|paljasta.{0,20}(nimi|henkilö)|vem äger|hänga ut/))choose('decline');
 else if(match(all,/\bex\b|former partner|monitoring (app|my|me)|stalkerware|entinen kumppani|seurantasovellu|tietää.{0,30}(kirjoitan|liikun)|övervakningsapp|min ex|före detta partner/)) {choose('monitoring','user_safety');needs=['device.recent_app_installs'];}
 else if(match(all,/ransom|files.{0,20}encrypted|bitcoin|lunnai|tiedostot.{0,30}salat|filer.{0,35}krypter|krypterade filer|\bbtc\b/)){choose('device');target=business?'business_security_support':'security_specialist';extra=['dont_pay_or_transfer','keep_evidence'];cite='guidance_ransomware';}
 else if(match(all,/router|reititin|reitittim|routern/)){choose('password');extra=['secure_router'];cite='guidance_router_security';}
 else if(match(op,/forwarding rule|edelleenlähety|vidarebefordr/) || (business&&match(all,/invoices from our|laskuja meidän|vääriä laskuja|valelaskuja|meidän osoitteesta/))){choose('password');extra=['check_forwarding_rules','inform_staff','assess_data_breach'];target='business_security_support';cite='guidance_business_email_compromise';}
 else if(match(all,/former employee|employee who left|ex.employee|entinen työntekijä|irtisanout|lähtenyt työntekijä|pois lähten|slutat|tidigare anställd/)){choose('password');needs=['business.staff_accounts'];extra=['revoke_access'];cite='guidance_offboarding';}
 else if(policeCall){
   ({id,topic,extra,target}=policeCallProcedure(op,all,facts));
   cite='guidance_police_impostor';
 }
 else if(match(all,/e-?sim|sim.kort|sim upgrade|sim.päivity|sim-uppgradering|number port|numeronsiir|numeron siir|nummerflytt/)){
   if(isCall){choose('operator','code_shared');needs=['subscription.recent_events'];cite='guidance_operator_impersonation';if(pol('code_shared')===false){choose('verify');extra=['hang_up_dont_call_back'];}}
   else {choose('operator','self_initiated');needs=['subscription.recent_events'];if(pol('self_initiated')===true){choose('benign');cite='guidance_esim_own_change';} }
 }
 else if(business&&match(all,/order confirmation|tilausvahvistus|beställningsbekräftelse|new subscriptions|uusia liittymiä/)){
   const ev=get(c.signals,'subscription.recent_events');
   const office=Array.isArray(ev)&&ev.some(e=>e.type==='new_subscription_order'&&e.delivery==='office_address');
   const authored=match(all,/office address|toimistoon|toimiston|kontorsadress|itse tilasin/);
   choose(office||authored?'benign':'operator',office||authored?null:'self_initiated');needs=['subscription.recent_events'];cite='guidance_order_confirmations';
   if(id==='operator'){needs.push('operator_account.recent_logins');extra=['change_password','review_sessions','enable_mfa'];target='business_security_support';}
   if(pol('self_initiated')===true){choose('operator');risk='low';extra=['contact_operator','verify_out_of_band'];target=business?'business_security_support':'operator_support_agent';}
 }
 else if(match(op,/lost signal|no signal|lost service|kenttä (katosi|hävisi)|ei (ole )?kenttää|ingen täckning/)){choose('operator','self_initiated');needs=['subscription.recent_events'];}
 else if(match(all,/approval request|approve sign.in|login approval|hyväksyntäpyyn|hyväksy.{0,20}kirjautumi|kirjautumispyyn|godkänna|godkänn inloggning/)){
   const own=match(op,/i.m (logging|signing) in|i am (logging|signing) in|kirjaudun.{0,35}(itse|juuri|nyt)|olen.{0,20}kirjautumassa|olen ottamassa.{0,60}kirjautu|loggar in.{0,30}(själv|nu)/)&&!match(op,/not logging|en.{0,12}kirjautu|inte loggar/);
   choose(own?'benign':'password');if(!own)extra=['dont_approve_prompts'];cite=own?'guidance_proportionate_advice':'guidance_mfa_fatigue';
 }
 else if(match(all,/logged in from|login from|signed in from|unknown login|kirjauduttiin|kirjautumisesta|tililleni.{0,20}kirjauduttu|inloggning från|konto.{0,20}spanien/)){
   choose('password','self_initiated');needs=['operator_account.recent_logins'];cite='guidance_unknown_login';if(pol('self_initiated')===true)risk='low';
 }
 else if(match(all,/remote|controlled my|etätu|etäyhte|etäohjel|etäkäyt|ohjasi kon|fjärr/)){
   const booked=match(op,/we booked|i booked|we arranged|usual it|booked remote|varasimme|sovimme|sovittu.{0,20}(etätu|it)|tilasimme itse|tiketin tein itse|tutulta it|oma.{0,15}it-kumppan|bokade|vanliga it/);
   const terminal=match(all,/terminal|till computer|maksupääte|kassakone|kassajärjestelm|betalterminal/);
   if(booked){choose('benign');cite='guidance_remote_access';}
   else if(terminal){choose('verify');extra=['dont_share_codes','verify_out_of_band'];cite='guidance_merchant_fraud';}
   else {choose('device','credentials_entered');needs=['device.security_findings'];cite='guidance_remote_access';if(pol('credentials_entered')===true){id='bank';extra=['disconnect_device','get_device_checked'];target='security_specialist';} }
 }
 else if(isCall){
   const bank=match(all,/bank|pank|safe account|turvatili|säkert konto/);
   const codes=match(all,/code|koodi|tunnuslu|\bkod/);
   if(match(all,/safe account|turvatili|säkert konto|siirsin jo|already moved|redan fört/)){choose('bank');extra=['report_police','hang_up_dont_call_back'];target='human_advisor';cite='guidance_police_impostor';}
   else if(bank&&codes){
     const shared=pol('code_shared');
     choose('bank','code_shared');
     cite='guidance_bank_impostor_call';
     if(shared===false){choose('verify');extra=['hang_up_dont_call_back'];}
     else if(shared===null&&facts.code_shared!==undefined){choose('check_bank_exposure');}
   }
   else if(bank){choose('verify');extra=['hang_up_dont_call_back'];cite='guidance_bank_verification';}
   else if(match(all,/appointment|health centre|clinic|terveyskesk|ajanvarau|vastaanotto|vårdcentral|hälsocentral|bokning/)){choose('benign');cite='guidance_spam_flag_meaning';}
   else if(match(all,/virus|software.{0,20}support|tekninen tuki|teknisestä tuesta|tech.{0,10}support/)){choose('scam');extra=['hang_up_dont_call_back'];cite='guidance_tech_support_fraud';}
   else {choose('verify');extra=['hang_up_dont_call_back'];cite='guidance_spam_flag_meaning';}
 }
 else if(business&&match(all,/\bzip\b|attachment|liite|liitteen|bilaga|enable content|salli sisältö/)&&!match(all,/\bceo\b|toimitusjohtaja|pomo|confidential|luottamukselli/)){
   choose(pol('app_installed')===false?'scam':'device','app_installed');extra=['dont_open_attachment'];cite='guidance_malicious_attachment';if(id==='device')target='business_security_support';
 }
 else if(business&&match(all,/\bceo\b|our boss|our manager|toimitusjohtaja|pomo|\bvd\b|confidential|luottamukselli|keep it secret/)){
   choose('bank','payment_status');extra=['dont_pay_or_transfer','verify_out_of_band','two_person_approval'];target='business_security_support';cite='guidance_ceo_fraud';
   if(pol('payment_status')===false){choose('payment');target=null;}
 }
 else if(business&&match(all,/bank account|account number|bank details|tilinumero|tili.{0,12}muuttu|uudelle tilille|uusi til|kontonummer|bankuppgift/)){
   const verified=match(op,/i called|called.{0,40}confirm|confirmed.{0,30}change|soitin.{0,180}(vahvist|varmist)|tarkistin.{0,100}(tuttuun|oikea)|vahvistin|varmistin|ringde.{0,60}bekräft/);
   choose(verified?'benign':'payment');cite='guidance_payment_verification';
 }
 else if(business&&match(all,/work email|työsähköposti|työsähköpostill|asiakirjan jakosiv|företagets e.post/)&&match(all,/sign.in|kirjaudu|salasan|password|logg/)){choose('password');extra=['check_forwarding_rules'];}
 else if(c.journey==='clicked_link'||match(op,/i (entered|typed|installed)|syötin|kirjoitin|asensin|skrev.{0,20}(lösenord|kod)/)){
   const installed=match(op,/i installed|asensin|installerade|latasin.{0,25}sovell|profiilin/);
   const bank=match(all,/bank|pank|bankuppgift/);
   const secret=match(op,/entered|typed|logged in|signed in|syötin|kirjoitin|kirjauduin|annoin|skrev|angav|loggade/);
   const explicitNo=match(op,/didn.t (enter|type|install)|did not (enter|type|install)|en (syöttänyt|kirjoittanut|asentanut)|inte (skrev|angav)/);
   const knownOrder=match(op,/i ordered.{0,25}(myself|just|now)|ordered just now|tilasin.{0,25}(itse|juuri|äsken)|beställde.{0,25}(själv|nyss)|kiitos tilauksestasi|thank you for your order/ );
   if(installed&&!explicitNo){choose('device');extra=['contact_bank_now'];needs=['device.recent_app_installs'];cite='guidance_malicious_app';}
   else if(secret&&bank&&!explicitNo){choose('bank');}
   else if(secret&&match(all,/password|salasan|lösenord|work email|työsähköpost|inloggn/)&&!explicitNo){choose('password');if(business)extra=['check_forwarding_rules'];}
   else if(knownOrder){choose('benign');cite='guidance_link_opened_no_input';}
   else {choose('bank','card_details_entered');if(pol('card_details_entered')===false||explicitNo){choose('scam');extra=['update_device'];cite='guidance_link_opened_no_input';}}
 }
 else if(match(all,/password reset|salasanan (vaihto|vaihtoa|palaut)|återställ.{0,15}lösenord|byta lösenord.{0,20}begär|lösenordsåterställ/)){choose('verify');cite='guidance_unrequested_reset';}
 else if(c.journey==='breach_notice'||match(all,/breach|leaked|tietovuoto|vuotaneet|tietoja vuot|dataläck/)){
   const emailOnly=match(all,/no passwords|no password|only.{0,25}email|names and email|vain.{0,25}(sähköposti|nimi)|salasanoja.{0,30}ei|ei.{0,20}salasano|inga lösenord|endast.{0,20}e.post/);
   const fake=match(all,/log.{0,8}in.{0,25}(within|hours)|kirjautumalla.{0,20}tunnin|secure your account within|suojaa tilisi.{0,25}tunnin/);
   if(fake){choose('verify');cite='guidance_fake_breach_notice';}
   else if(emailOnly){choose('benign');cite='guidance_breach_response';}
   else if(match(all,/password|salasan|lösenord/)){choose('password');cite='guidance_breach_response';}
   else choose('verify');
 }
 else {
   const links=Array.isArray(artifact?.links)?artifact.links:[];
   const request=match(body,/pay.{0,20}(fee|eur|€)|maksa|betala|log in|kirjaudu|tunnistaudu|confirm.{0,15}(details|identity)|päivitä.{0,20}kort|update.{0,15}card|read.{0,15}code/);
   const lc=c.signals?.link_check; const noSecret=!request;
   const routine=match(body,/available.{0,20}(app|account)|laskusi.{0,40}oma|new message.{0,20}(online bank|bank)|nytt meddelande.{0,30}banken|kan hämtas|pickup code|can be collected|uusi viesti|lasku.{0,70}(oma|verkko)|nouto|sovelluksesta|no links|ei.{0,8}linkk|no credentials|eivät pyydä|samma pris|same price|samaan hintaan|new payee|uusi maksunsaaja|ny betalningsmottagare/);
   const marketing=noSecret&&match(body,/offer|tarjous|tarjoukset|erbjudande|faster 5g|nopeampi/);
   if(noSecret&&((!links.length&&routine)||marketing||(lc?.verdict==='clean'&&routine))){choose('benign');}
   else if(match(all,/bank|pank|locked|lukittu|stream|payment failed|maksu.{0,10}epäonn|operaattori|subscription.{0,20}cut|liittymä.{0,25}sulje|identification.{0,20}expir|tunnistautumi/)){choose('verify');risk=match(all,/bank|pank|tunnistau|identification/)?'high':'medium';}
   else if(match(all,/mum|mom|child|new number|äiti|laps|uusi numero|mamma|nytt nummer/)){choose('payment');extra=['dont_reply'];cite='guidance_family_new_number';}
   else if(match(all,/parcel|delivery fee|customs|paket|tulli|lahjakort|gift card|prize|won|voitt|investment|invest|sijoit|tax refund|veronpalaut|skatteåterbär/)){choose('scam');risk=match(all,/bank credentials|pankkitunn|tunnistau/)?'high':'medium';}
   else if(links.length||request){choose('verify');}
   else choose('uncertain','message_content');
 }
 const base=PROCEDURES[id];
 if(topic&&facts[topic]!==undefined)topic=null;
 conditional=!!topic&&['bank','device','operator','password'].includes(id);
 return {id,action:base.action,risk:risk??base.risk,steps:[...new Set([...base.steps,...extra])],target:target===undefined?base.target??null:target,topic,needs,cite:cite??base.cite,conditional,why:base.why};
}

export function analyze(input,options={}) {
 const granted=options.granted??[]; const facts=options.facts??{}; const c=authorizedInput(input,granted);
 const p=selectProcedure(c,facts);const lang=['en','fi','sv'].includes(c.language)?c.language:'en';
 const allowed=new Set([...(c.consent.pre_granted??[]),...granted]); const gated=new Set(c.consent.requires_consent??[]);
 const requests=p.needs.filter(path=>gated.has(path)&&!allowed.has(path)&&!options.refused?.includes(path));
 // Deliberately access only needed context; a populated field is not permission.
 const used=['artifact'].filter(k=>!!c.signals[k]);
 for(const path of p.needs)if((!gated.has(path)||allowed.has(path))&&get(c.signals,path)!=null&&get(c.signals,path)!=='available_with_consent')used.push(path);
 const provisional=textAt(["Until that is clarified, follow these steps if the exposure or change was unauthorized.","Kunnes asia selviää, noudata näitä ohjeita, jos tiedot paljastuivat tai muutos oli luvaton.","Tills detta är klarlagt gäller stegen om uppgifterna röjdes eller ändringen var obehörig."],lang);
 const steps=p.steps.map(k=>textAt(STEPS[k],lang));
 if(p.conditional&&p.topic==='self_initiated'&&p.id==='operator')steps.push(textAt(["If you initiated the change yourself, this appears normal; confirm the details in the official app.","Jos teit muutoksen itse, tämä vaikuttaa normaalilta; tarkista tiedot omasta sovelluksesta.","Om du själv gjorde ändringen verkar det normalt; kontrollera uppgifterna i den officiella appen."],lang));
 if(p.conditional&&p.topic==='card_details_entered')steps.push(textAt(["If you entered nothing and installed nothing, report the message as a scam and delete it.","Jos et syöttänyt tietoja tai asentanut mitään, ilmoita viesti huijaukseksi ja poista se.","Om du inte skrev in uppgifter eller installerade något, rapportera meddelandet som bedrägeri och radera det."],lang));
 let advice=steps.slice(0,2).join(' ')+' '+textAt(p.why,lang);
 if(p.conditional)advice=textAt(["If you shared sensitive information or did not authorize this event, ","Jos luovutit arkaluonteisia tietoja tai et hyväksynyt tätä tapahtumaa, ","Om du delade känsliga uppgifter eller inte godkände händelsen, "],lang)+advice.charAt(0).toLowerCase()+advice.slice(1)+' '+provisional;
 const questionKey = p.id==='police_check' && p.topic==='credentials_entered' ? 'police_details_shared' : p.topic;
 const question=questionKey?textAt(QUESTIONS[questionKey],lang):null;
 const uncertainty=textAt(["This prototype cannot verify the sender, scan a device or confirm a live account state.","Tämä prototyyppi ei voi vahvistaa lähettäjää, tarkistaa laitetta tai varmistaa tilin reaaliaikaista tilaa.","Prototypen kan inte verifiera avsändaren, skanna en enhet eller bekräfta kontots aktuella tillstånd."],lang);
 const answer={case_id:c.case_id??'custom',mode:options.mode??'single_turn',risk_level:p.risk,urgency:['critical'].includes(p.risk)?'immediate':p.risk==='high'?'today':p.risk==='low'?'routine':p.risk==='none'?'none':'routine',primary_action:p.action,advice_text:advice,steps,escalation_required:!!p.target,escalation_target:p.target,questions_asked:question?[question]:[],question_topics:p.topic?[p.topic]:[],signals_used:used,consent_requested_for:[...(options.requested??[]),...requests].filter((v,i,a)=>a.indexOf(v)===i),citations:[p.cite],confidence:p.id==='uncertain'?0.35:p.conditional?0.6:0.78,abstained:p.id==='uncertain',notes:'Rule-guided prototype; confidence is a heuristic, not a calibrated probability. No live action is performed.'};
 return {answer,procedure:p.id,question,topic:p.topic,consentRequests:requests,reason:textAt(p.why,lang),uncertainty,conditional:p.conditional};
}

export function step(event,state={}) {
 if(event.type==='start'){for(const k of Object.keys(state))delete state[k];Object.assign(state,{case:visibleInput(event.case),facts:{},granted:[],refused:[],requested:[],questions:[],questionTexts:[],last:null});}
 if(!state.case)throw new Error('Conversation must begin with a start event');
 if(event.type==='user_reply'&&state.last)state.facts[state.last]=String(event.text??'').slice(0,4000);
 if(event.type==='consent_reply'){
   state.granted.push(...(event.granted??[]));state.refused.push(...(event.refused??[]));
   for(const [p,v]of Object.entries(event.signals??{}))if(state.granted.includes(p))put(state.case.signals,p,v);
 }
 const result=analyze(state.case,{...state,mode:'multi_turn'});
 if(event.type!=='turn_limit'){
   if(result.topic&&!state.questions.includes(result.topic)){state.last=result.topic;state.questions.push(result.topic);state.questionTexts.push(result.question);return {type:'question',text:result.question,topics:[result.topic]};}
   if(result.consentRequests.length){state.requested.push(...result.consentRequests);return {type:'consent_request',fields:result.consentRequests,text:textAt(["May I use just the listed account or device information to check this event? You can decline.","Saanko käyttää vain lueteltuja tili- tai laitetietoja tämän tapahtuman tarkistamiseen? Voit kieltäytyä.","Får jag använda endast de angivna konto- eller enhetsuppgifterna för att kontrollera händelsen? Du kan säga nej."],state.case.language)};}
 }
 result.answer.question_topics=[...state.questions];result.answer.questions_asked=[...state.questionTexts];
 return {type:'final',answer:result.answer};
}
