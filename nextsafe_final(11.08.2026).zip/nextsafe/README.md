# NextSafe digital security assistant

An independent DNA × Since AI 2026 hackathon prototype. An English-only web app gives a clear first action, asks a decisive question, obtains consent for optional context, and prepares a human handoff summary. This version uses deterministic safety procedures and the supplied synthetic guidance corpus. It does not call a language model or any DNA API.

## Quick start

Requires Node.js 22.13+ for the web app and Python 3.10+ for the organizer evaluator. No API key or GPU is needed.

```bash
npm install
npm run dev
```

Open the local URL printed by the development server. A pnpm lockfile is supplied; pnpm may be used instead of npm. To test the zero-dependency decision engine without installing web dependencies:

```bash
node --test tests/engine.test.mjs
```

## Use Codex

Open this project folder in VS Code, install the official OpenAI Codex extension, sign in and open its sidebar. Ask it to read `AGENTS.md`, `CODEX_TASK.md` and this README. Review the proposed edits and measured results. The existing code is a working starting point; do not ask Codex to regenerate the whole app.

Official setup: https://learn.chatgpt.com/docs/codex/ide

## Reproduce the evaluation

Run these commands from the project root. The organizer package in `challenge-kit` is unchanged, including its evaluator and manifest. CLI prediction strips ground truth, simulation, family IDs, tags and other development-only metadata before inference.

The five-journey benchmark reports and limitations are in [`evidence/RESULTS.md`](evidence/RESULTS.md). They accompany the submission as offline evidence. The consumer interface focuses on individual assessments.

```bash
python3 challenge-kit/tools/validate.py
python3 challenge-kit/baselines/rules_baseline.py --cases challenge-kit/data/dev/cases.jsonl --out evidence/baseline_dev.jsonl
python3 challenge-kit/eval/evaluate.py --cases challenge-kit/data/dev/cases.jsonl --submission evidence/baseline_dev.jsonl
node cli/predict.mjs --cases challenge-kit/data/dev/cases.jsonl --out evidence/dev_predictions.jsonl
python3 challenge-kit/eval/evaluate.py --cases challenge-kit/data/dev/cases.jsonl --submission evidence/dev_predictions.jsonl --json > evidence/dev_report.json
python3 challenge-kit/sim/run_conversation.py --cases challenge-kit/data/dev/cases.jsonl --bot "node cli/bot.mjs" --out evidence/dev_multiturn.jsonl
python3 challenge-kit/eval/evaluate.py --cases challenge-kit/data/dev/cases.jsonl --submission evidence/dev_multiturn.jsonl --json > evidence/multiturn_report.json
node cli/predict.mjs --cases challenge-kit/data/test/inputs.jsonl --out test_predictions.jsonl
python3 challenge-kit/tools/validate.py --submission test_predictions.jsonl --cases challenge-kit/data/test/inputs.jsonl
```

The web interface and its advice are English-only. The offline evaluation adapter retains Finnish, English and Swedish to respect the supplied benchmark contract. Do not describe its multilingual scores as measurements of English-only output on every language. Browser advice uses a generated English copy of the shared engine. After editing `core/engine.mjs` or `core/knowledge.mjs`, run `node cli/build-browser.mjs`. The parity test checks that the browser and CLI give the same English result.

## Files

- `app/`: English-only React interface using the provided Vinext starter.
- `core/engine.mjs`: observable-behavior policy selection, consent masking and conversation state.
- `core/knowledge.mjs`: hand-authored procedures and translations for offline evaluation.
- `core/browser-engine.mjs`, `core/knowledge.en.mjs`: generated browser files.
- `core/guidance.json`: English synthetic guidance, explicitly not official advice.
- `cli/predict.mjs`: JSONL batch prediction; no web dependencies needed.
- `cli/bot.mjs`: standard-input/output multi-turn simulator protocol.
- `tests/`: regression checks for consent, injection, safety and label isolation.
- `evidence/`: measured development predictions, reports and failure discussion.
- `test_predictions.jsonl`: all 335 hidden-test inputs, single-turn predictions.
- `NextSafe_Colab.ipynb`: optional data exploration and evaluation notebook.
- `challenge-kit/`: the supplied package, with MIT code and CC BY 4.0 data/documentation.

## Privacy and safety boundaries

Assessments run locally in browser memory. Inputs are not sent to a model provider, persisted as chat history, or uploaded to a backend. Optional signals are masked before selection and used only after permission or a pre-grant. Declining still produces useful advice. A supplied context value is not consent. Account identification is simulated; there is no real DNA identity integration.

The app never opens suspicious links, calls sample numbers, scans devices, blocks cards, changes passwords or sends handoffs. Exported summaries require the user to share them independently. All challenge domains and phone numbers are synthetic. Never call sample numbers. Guidance is authored by Since AI and is not official DNA or authority guidance.

Confidence values in machine-readable output are explicitly heuristic, not calibrated probabilities. No confidence percentage is shown to consumers. Conditional advice does not establish that a compromise occurred. Human reviewers must assess instructions and uncertainty before deployment to real users.

## Limitations and next work

Rules were developed using the 588 dev cases, so the high development score is an in-sample measurement. There is no independent holdout result, and hidden-test labels remain unavailable. Rules can miss unfamiliar language and scenarios. Automated safety and step checks are heuristic and cannot certify safe behavior. Review the named failures in `evidence/RESULTS.md` and run a real comprehension check before submission.

The current environment could not provide a browser preview daemon. TypeScript, engine tests, schema validation and the production build are checked; visual and click-through browser verification remain pending.

An optional language-model component can later extract structured facts for unfamiliar phrasing, while keeping consent enforcement and response validation outside the model. That component is not implemented or benchmarked here. Codex is a development tool; it does not automatically become the deployed app's model.

## Packaging hypothesis

Consumers could receive this assistant inside an existing operator app. Small businesses could add employee incident intake and reviewable IT handoff summaries. These are packaging hypotheses; pricing, demand and production readiness have not been validated.

## Attribution

Challenge dataset, guidance and documentation: © 2026 Since AI ry, CC BY 4.0. Organizer code: MIT. See `challenge-kit/LICENSE`. The supplied starter and third-party dependencies retain their respective licenses. New application and engine code is MIT under `LICENSE`.
