# Continue NextSafe with Codex

Read AGENTS.md, README.md and evidence/RESULTS.md. Explain the architecture briefly, then run the existing tests and evaluator to reproduce the actual results.

Keep the UI and app advice English-only and lightweight. Keep multilingual behavior isolated in the offline benchmark adapter. Do not recreate the project or change the organizer's evaluator.

Next priorities:

1. Run the app locally and complete browser verification on desktop and a narrow mobile screen. Walk through all five sample journeys, a declined consent request, a benign alert and the monitoring-app example. Check keyboard access, imported JSON cases, exports and handoff summaries.
2. Examine the documented failures. Fix underlying reasoning gaps without memorizing case IDs or families. Add independently written adversarial and benign cases before claiming generalization.
3. Ask the user which model provider and budget they want before adding a paid model integration. Add any approved model only on a server with environment secrets, constrained fact extraction, output validation and injection isolation. Keep a deterministic fallback and measure cost and latency.
4. Rerun single-turn and multi-turn evaluation after material changes. Preserve test predictions as single-turn. Validate all 335 test outputs. Never invent test labels or claim that a development score is hidden-test accuracy.
5. Complete the human comprehension check and manual safety review. Document at least one failure honestly. Prepare the final demo walkthrough and update results.

Deliver concrete code and measured evidence. State what was tested and what remains unverified.
