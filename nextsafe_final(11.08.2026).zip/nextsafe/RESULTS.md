# Results — NextSafe

DNA × Since AI 2026 digital security assistant

## 1. What we built

An English-only web interface and a shared deterministic decision engine provide prioritized safety advice, targeted follow-up questions, consent controls, cited challenge guidance and downloadable handoff summaries. The app runs locally in browser memory. A zero-dependency Node adapter produces the required JSONL and speaks the simulator protocol. No language model or live DNA API is called in this version.

## 2. Safety boundaries

Ground truth, simulation facts, family labels and development metadata are stripped before inference. Optional fields are masked before policy selection unless pre-granted or explicitly allowed. The app never visits suspect links, scans devices, changes accounts, blocks payments or sends handoffs. Forwarded text is untrusted evidence, and privacy requests cannot mutate object prototypes. The guidance corpus is synthetic and not official advice.

## 3. Five journeys

The following are multilingual offline adapter measurements. The consumer app itself is English-only. Policies were developed on these same 588 cases, so these are in-sample development measurements, not an independent validation result.

| Journey | Cases | Single-turn pass | Multi-turn pass | Human safety review |
|---|---:|---:|---:|---|
| breach_notice | 120 | 98.3% | 99.2% | Independent review pending |
| clicked_link | 84 | 95.2% | 94.0% | Independent review pending |
| smb_incident | 156 | 100.0% | 94.2% | Independent review pending |
| suspicious_call | 72 | 100.0% | 100.0% | Independent review pending |
| suspicious_message | 156 | 99.4% | 99.4% | Independent review pending |

Single-turn headline: 98.8% safe-action pass; 3.8% false alarms on benign cases; 100.0% escalation recall. Bootstrap 95% interval: [97.8, 99.7]. The weighted proxy is 96.3/100 over the 80 automated points; it does not include the 20 points for implementation.

Multi-turn headline: 97.3% safe-action pass; 3.8% false alarms; 97.1% escalation recall.

Organizer rules baseline reproduced: 60.5% single-turn pass and 28.0% false alarms. No hidden-test accuracy can be reported because the labels are unavailable.

Evaluator: supplied v2.0.1, unchanged. Commands and full reports are in README.md and evidence/*.json.

## 4. False alarms

- DSA-D-0179: Tämä huolestuttaa minua. Avasin linkin verkkokaupan vahvistusviestistä. Onko vaarallista? The app selected `contact_bank_and_block_cards` with `critical` risk. The reference treats the event as benign. This shows that cautious defaults can overreact when routine-order evidence is phrased differently.
- DSA-D-0252: hjälp! jag fick ett mejl om min faktura men vet inte om det är äkta. det finns ingen länk. vad gör jag nu?? jag är inte så bra på teknik The app selected `verify_via_official_channel` with `medium` risk. The reference treats the event as benign. This shows that cautious defaults can overreact when routine-order evidence is phrased differently.
- DSA-D-0413: Nyt on hätä! Avasin linkin verkkokaupan vahvistusviestistä. Onko vaarallista? Mitä teen nyt?? The app selected `contact_bank_and_block_cards` with `critical` risk. The reference treats the event as benign. This shows that cautious defaults can overreact when routine-order evidence is phrased differently.
- DSA-D-0432: Tämä huolestuttaa minua. Avasin linkin verkkokaupan vahvistusviestistä. Onko vaarallista? The app selected `contact_bank_and_block_cards` with `critical` risk. The reference treats the event as benign. This shows that cautious defaults can overreact when routine-order evidence is phrased differently.
- DSA-D-0531: avasin linkin verkkokaupan vahvistusviestistä. onko vaarallista? en oo kovin hyvä näissä teknisissä jutuissa The app selected `contact_bank_and_block_cards` with `critical` risk. The reference treats the event as benign. This shows that cautious defaults can overreact when routine-order evidence is phrased differently.

## 5. Failure and escalation examples

DSA-D-0179 is a meaningful failure: an ordinary order-tracking link was treated as possible card exposure. The assistant asked about card details and gave conditional banking advice, but this was disproportionate to the described event. Improve exposure triage using independently written routine-order cases rather than memorizing the case.

For the monitoring-app sample, the assistant asks whether the user is physically safe, advises planning before removal, and routes the user to a trained human advisor. The handoff is a reviewable local summary, not a real connection.

Multi-turn escalation recall is below 100%; inspect missed handoffs in multiturn_report.json. No automated unsafe-statement matches is not proof that every instruction is safe.

Police impersonation regression checks distinguish a caller’s identity claim, a request for money or sensitive details, and exposure reported by the user. Identity-only and declined requests lead to independent police verification. Reported financial exposure prioritizes the bank and adds police reporting. Unclear exposure produces conditional advice. A caller’s assertion of an unauthorized payment does not establish that the user observed one.

## 6. Comprehension check

Pending: the team must read three outputs to someone outside the team, record their own description of the next step, and note whether the action was understood. No listener, response or review outcome has been invented.

| Case | Listener’s own words | Understood? |
|---|---|---|
| Suspicious message | Pending | Pending |
| Bank-code call | Pending | Pending |
| Business payment | Pending | Pending |

## 7. Privacy and consent

The engine requests only procedure-relevant paths such as recent SIM events, device findings or staff access. In multi-turn it uses them only after a grant; a refusal remains recorded and does not cause another consent request. Single-turn asks for relevant optional context but does not consume it without a prior grant. Signals-used fields describe authorized paths, not all populated input fields.

## 8. Packaging hypothesis

An operator could include the consumer experience in its identified-customer app and offer incident intake plus IT handoff to small businesses. A subscription bundle or business add-on could be tested; no price, demand, retention lift or revenue is proven.

## 9. Verification limits

20 engine regression checks pass, including label isolation, consent refusal, prompt injection, personal-safety priority and English browser/CLI parity. TypeScript checks and a production build passed. Browser preview infrastructure is unavailable, so visual, mobile and click-through QA remain pending. The Colab notebook has not been run on a live Colab account; its evaluation commands were exercised locally. Independent human safety review is pending.

## 10. Submission files

- test_predictions.jsonl: 335 single-turn outputs, schema and coverage validated.
- evidence/dev_report.json and evidence/multiturn_report.json.
- Source, README.md, AGENTS.md, CODEX_TASK.md and NextSafe_Colab.ipynb.
- Demo recording and independent human comprehension check still to be completed by the team.
