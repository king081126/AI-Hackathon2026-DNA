import readline from 'node:readline';
import {step} from '../core/engine.mjs';
const state={};
for await(const line of readline.createInterface({input:process.stdin,crlfDelay:Infinity})){
 try{const reply=step(JSON.parse(line),state);process.stdout.write(JSON.stringify(reply)+'\n');}
 catch(e){console.error(e.message);process.exitCode=1;break;}
}
