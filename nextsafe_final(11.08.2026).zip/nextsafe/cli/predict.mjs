import fs from 'node:fs';
import {analyze,visibleInput} from '../core/engine.mjs';
const args=process.argv.slice(2); const value=k=>args[args.indexOf(k)+1];
if(!args.includes('--cases')||!args.includes('--out')){console.error('Usage: node cli/predict.mjs --cases INPUT.jsonl --out OUTPUT.jsonl');process.exit(1);}
const cases=fs.readFileSync(value('--cases'),'utf8').split(/\r?\n/).filter(Boolean).map(JSON.parse);
const seen=new Set(); const output=cases.map(c=>{if(seen.has(c.case_id))throw new Error('Duplicate case ID');seen.add(c.case_id);return analyze(visibleInput(c)).answer;});
fs.writeFileSync(value('--out'),output.map(a=>JSON.stringify(a)).join('\n')+'\n');
console.error(`Wrote ${output.length} predictions. Only visible input fields were passed to the engine.`);
